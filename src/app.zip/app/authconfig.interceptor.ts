import {Injectable} from '@angular/core';
import {HttpHandler, HttpInterceptor, HttpRequest} from '@angular/common/http';
import {AuthService} from './auth.service';
import {Observable} from 'rxjs';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  // tslint:disable-next-line:variable-name
  constructor(private _authService: AuthService) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<any> {
    const authToken = this._authService.getAccessToken();
    if (authToken != null) {
      req = req.clone({
        setHeaders: {
          Authorization: authToken
        }
      });
    }

    return next.handle(req);
  }

}
