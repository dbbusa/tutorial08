import { Component, OnInit } from '@angular/core';
import {AuthService} from '../auth.service';
import {Router} from '@angular/router';
import {FormControl, FormGroup} from '@angular/forms';


@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css']
})
export class SigninComponent implements OnInit {

  signinForm: FormGroup;

  // tslint:disable-next-line:variable-name
  constructor(private _authService: AuthService, private _router: Router) {
    this.signinForm = new FormGroup({
      username: new FormControl(''),
      password: new FormControl(''),
    });
  }


  ngOnInit(): void {
    if (this._authService.isLoggedIn() === true){
      this._router.navigate(['/video']);
    }
  }

  // tslint:disable-next-line:typedef
  onSubmit() {
    console.log(this.signinForm.value);
    this._authService.login(this.signinForm.value);
  }
}
