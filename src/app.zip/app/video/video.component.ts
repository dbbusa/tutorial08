import { Component, OnInit } from '@angular/core';
import {IVideo} from '../models/videos';
import {AuthService} from '../auth.service';

@Component({
  selector: 'app-video',
  templateUrl: './video.component.html',
  styleUrls: ['./video.component.css']
})
export class VideoComponent implements OnInit {

  dataRes: IVideo[];
  // tslint:disable-next-line:variable-name
  constructor(private _authService: AuthService) { }

  ngOnInit(): void {
    this._authService.getVideo().subscribe(res => {
      this.dataRes = res;
      console.log(this.dataRes);
    });
  }

}
