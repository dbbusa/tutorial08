export class User {
  // tslint:disable-next-line:ban-types variable-name
  _id: String;
  // tslint:disable-next-line:ban-types
  username: String;
  // tslint:disable-next-line:ban-types
  password: String;
}
