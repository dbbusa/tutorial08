export interface IVideo {
  cat: string[];
  _id: string;
  title: string;
  desc: string;
  posted_by: string;
  url: string;
  likes: number;
  createdAt: Date;
  updatedAt: Date;
  __v: number;
}
