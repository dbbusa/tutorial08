import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Route, Router} from '@angular/router';
import {User} from './models/user';
import {Observable} from 'rxjs';
import {observableToBeFn} from 'rxjs/internal/testing/TestScheduler';
import {getToken} from 'codelyzer/angular/styles/cssLexer';
@Injectable({
  providedIn: 'root'
})
export class AuthService {

  url = 'http://localhost:3000/api/';

  // tslint:disable-next-line:variable-name
  constructor(private _http: HttpClient, private _router: Router) {
  }

  // tslint:disable-next-line:typedef
  signup(user: User): Observable<any> {
    return this._http.post<any>(this.url + 'register', user);
  }

  // tslint:disable-next-line:typedef
  login(user: User) {
    return this._http.post<any>(this.url + 'login', user).subscribe((res: any) => {
      console.log(res);
      localStorage.setItem('access-token', res.authtoken);
      this._router.navigate(['/video']);
    });
  }

  isLoggedIn(): boolean {
    const authToken = localStorage.getItem('access-token');
    return (authToken) !== null ? true : false;
  }
  // tslint:disable-next-line:typedef
  logout(){
    if (localStorage.removeItem('access-token') == null){
      this._router.navigate(['/signin']);
    }
  }

  getVideo(): Observable<any>{
    return this._http.get(this.url + 'video', {headers: {'auth-token': `${this.getAccessToken()}`}});
  }
  // tslint:disable-next-line:typedef
  getAccessToken(){
    return localStorage.getItem('access-token');
  }
}
